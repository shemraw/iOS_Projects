//
// Sphoorthy Masa
//

import UIKit

typealias PieceID = Int

class Game: NSObject {
    
    var nextId = 0
    //Create a peiceId which returns a Int
    func createPiece() -> PieceID {
        nextId += 1
        return nextId
    }
    
    func isSelected(pieceID id: PieceID) -> Bool {
        return false
    }
    
    // Scores Array
    var scores:Array = [0, 0, 0]
}

