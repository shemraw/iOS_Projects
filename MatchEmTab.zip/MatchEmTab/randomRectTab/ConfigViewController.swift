


import UIKit


class ConfigViewController: UIViewController {
    
    var randomRectanglesVC: RandomRectangleViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        randomRectanglesVC = self.tabBarController!.viewControllers![0]
            as? RandomRectangleViewController
        
    }
    
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var speedSlider: UISlider!
    @IBOutlet weak var scoreLabel: UILabel!
    
    
    @IBOutlet weak var segControl: UISegmentedControl!
    
    @IBAction func bkCol(_ sender: UISegmentedControl) {
        switch segControl.selectedSegmentIndex{
        case 0:
            randomRectanglesVC?.view.backgroundColor = .white
        case 1:
            randomRectanglesVC?.view.backgroundColor = .lightGray
        case 2:
            randomRectanglesVC?.view.backgroundColor = .blue
        default:
            break;
        }
    }
   
    
    
    @IBOutlet weak var sizeChangedLabel: UILabel!
    
    @IBAction func changeSize(_ sender: UIStepper) {
        sizeChangedLabel.text = String(sender.value)

        randomRectanglesVC?.changeSize = randomRectanglesVC!.changeSize + CGFloat(sender.value)
        
    }
    
    var sliderLabelMessage: String {
        return String(format: "%.2f", speedSlider.value)
    }
    
    @IBAction func changeSpeed(_ sender: UISlider) {
        // Update the speed in the game
        randomRectanglesVC?.newRectInterval = TimeInterval(speedSlider.value)
        
        // Update the slider's label
        speedLabel.text = sliderLabelMessage
    }
    
    @IBAction func changeRectCol(_ sender: UISwitch) {
            
        if sender.isOn == true{
            randomRectanglesVC?.newAlphaCol = 9999
        }
        else {
            randomRectanglesVC?.newAlphaCol = 0
        }
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
       
        scoreLabel.text = "Last three scores: \t \t \(String(describing: (randomRectanglesVC?.game.scores[0])!)) \t \(String(describing: (randomRectanglesVC?.game.scores[1])!)) \t \(String(describing: (randomRectanglesVC?.game.scores[2])!))"
        
        // Get the current speed
        let currentDelay = Float((randomRectanglesVC?.newRectInterval)!)
        
        // Init the slider position
        speedSlider.value = currentDelay
        
        // Init the slider's label, depends on slider.value
        speedLabel.text = sliderLabelMessage
    }
    
    
    
}
