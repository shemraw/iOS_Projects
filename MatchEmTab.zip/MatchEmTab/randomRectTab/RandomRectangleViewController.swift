//
// Sphoorthy Masa
// MatchEmTab
//

import UIKit

class RandomRectangleViewController: UIViewController {
    
    
    @IBOutlet weak var gameLabel: UILabel!
    var changeSize : CGFloat = 0
    var newAlphaCol : CGFloat = 0
    var inProgess = false
    var isRunning = false
    
    private let rectSizeMin : CGFloat = 50
    public var rectSizeMax : CGFloat = 100
    
    // MARK: - ==== Management Properties ====
    //private var theButton: UIButton?
    
    var game = Game()
    var i = 0
    
    private var buttonDict = [UIButton : PieceID]()
    
    private var newRectTimer: Timer?
    var newRectInterval: TimeInterval = 1.0
    
    var gameTimer: Timer?
    var gameDuration: TimeInterval = 15.0
    
    
    
    //Count & Score & Time remainign Label
    private var buttonCount = 0 {
        didSet {
            gameLabel.text = gameLabelMessage
        }
    }
    var timeRemaining =  0 {
        didSet{
            gameLabel.text = gameLabelMessage
        }
    }
    private var score = 0{
        didSet {
            gameLabel.text = gameLabelMessage
        }
    }
    
    
    private var gameLabelMessage: String {
        return "Count: \(buttonCount) \t Score: \(score) \t Time left: \(timeRemaining) "
    }
    
    
    // MARK: - ==== Rectangle Funcs ====
    public func createButton() {
        // Create a button
        //Getting random size for two buttons
        let randSize     = randomSize()
        //Getting two random locations on screen
        let randLocation1 = randomLocation(size: randSize)
        let randLocation2 = randomLocation(size: randSize)
        let randFrame1    = CGRect(origin: randLocation1, size: randSize)
        let randFrame2    = CGRect(origin: randLocation2, size: randSize)
        let buttonColor = getRandomColor()
        let button1 = UIButton(frame: randFrame1)
        let button2 = UIButton(frame: randFrame2)
        
        // Button1 setup
        button1.backgroundColor = buttonColor
        button1.setTitle("", for: .normal)
        button1.setTitleColor(.white, for: .normal)
        button1.titleLabel?.font = .systemFont(ofSize: 50)
        button1.showsTouchWhenHighlighted = true
        
        //Button2 setup
        button2.backgroundColor = buttonColor
        button2.setTitle("", for: .normal)
        button2.setTitleColor(.white, for: .normal)
        button2.titleLabel?.font = .systemFont(ofSize: 50)
        button2.showsTouchWhenHighlighted = true
        
        
        // Set up target/action
        button1.addTarget(self, action: #selector(handlePress(sender:)),
                          for: .touchUpInside)
        button2.addTarget(self, action: #selector(handlePress(sender:)),
                          for: .touchUpInside)
        
        // Count the buttons
        buttonCount += 1
        // Get game piece for the button
        let pieceId = game.createPiece()
        buttonDict[button1] =  pieceId
        buttonDict[button2] = pieceId
        
        // Make the button visible
        self.view.addSubview(button1)
        self.view.addSubview(button2)
        self.view.bringSubviewToFront(gameLabel)
    }
    
    func removeButton(_ theButton: UIButton) {
        theButton.removeFromSuperview()
    }
    
    func removeAllButtons(){
        for (button, _) in buttonDict {
            button.removeFromSuperview()
            buttonDict[button] = nil
        }
    }
    
    
    // MARK: - ==== Game Time Functions ====
    func startNewGame(){
        score = 0
        buttonCount = 0
        removeAllButtons()
        inProgess = true
        timeRemaining = Int(gameDuration)
        resumeGame()
    }
    
    func gameOver (){
        pauseGame()
        //game.scores.remove(at: 0)
        //game.scores.append(score)
        game.scores[i] = score
        i += 1
        
        if i==3 {
            i=0
        }
        
        
        inProgess = false
    }
    
    private func pauseGame() {
        isRunning = false
        // Stop the timer
        if let timer = newRectTimer { timer.invalidate()
        }
        
        // Remove the reference to the timer object
        self.newRectTimer = nil
        
        // Stop the timer
        if let timer = gameTimer { timer.invalidate() }
        self.gameTimer = nil
    }
    
    func resumeGame(){
        isRunning = true
        // Timer to produce the buttons
        newRectTimer = Timer.scheduledTimer(withTimeInterval: newRectInterval,
                                            repeats: true)
        { _ in self.createButton() }
        
        // Timer to stop producing the buttons
        gameTimer = Timer.scheduledTimer(withTimeInterval: 1,
                                         repeats: true)
        { _ in self.decrementCounter()}
    }
    
    
    func decrementCounter(){
        timeRemaining -= 1
        if timeRemaining == 0 {
            gameOver()
            self.view.bringSubviewToFront(gameLabel)
        }
    }
    
    // MARK: - ==== Random Value Funcs ====
    
    // Getting random size
    private func randomSize() -> CGSize {
        // Random Rectangle Size
        let randWidth  = randomFloatZeroThroughOne() * (rectSizeMax - rectSizeMin) + rectSizeMin + changeSize
        let randHeight = randomFloatZeroThroughOne() * (rectSizeMax - rectSizeMin) + rectSizeMin + changeSize
        let randSize = CGSize(width: randWidth, height: randHeight)
        return randSize
    }
    
    
    //Getting random location
    private func randomLocation(size rectSize: CGSize) -> CGPoint {
        // Screen dimensions
        let screenWidth = view.frame.size.width
        let screenHeight = view.frame.size.height
        let rectX = randomFloatZeroThroughOne() * (screenWidth  - rectSize.width)
        let rectY = randomFloatZeroThroughOne() * (screenHeight - rectSize.height)
        let location = CGPoint(x: rectX, y: rectY)
        return location
    }
    
    
    // getting Random color through RGB
    public var isRedOn = true
    public func getRandomColor() -> UIColor {
        let randGreen = randomFloatZeroThroughOne() + newAlphaCol
        let randBlue  = randomFloatZeroThroughOne() + newAlphaCol
        let randRed = randomFloatZeroThroughOne() +  newAlphaCol
        
        let alpha:CGFloat = 1.0
        return UIColor(red: randRed, green: randGreen, blue: randBlue, alpha: alpha)
    }
    
    
    // Support function to get random number
    private func randomFloatZeroThroughOne() -> CGFloat {
        // arc4random returns UInt32
        let randomFloat = CGFloat(Float(arc4random()) / Float(UINT32_MAX))
        return randomFloat
    }
    
    // MARK: - ==== Game Box Checking ===
    
    //Checking two same rectangles or not
    private var tempPieceId = 0
    var buttonPressed : UIButton?
    @objc private func handlePress(sender: UIButton) {
        //disabling button touch after time is completed
        if !isRunning || !inProgess{
            return
        }
        let pieceId = buttonDict[sender]!
        
        // Storing the first button click
        if tempPieceId == 0{
            sender.setTitle("👾", for: .normal)
            buttonPressed = sender
            tempPieceId = (pieceId)
            
        }
            // Checking the same button pressed or another
        else{
            if (pieceId == tempPieceId && buttonPressed != sender){
                removeButton(sender)
                removeButton(buttonPressed!)
                score += 1
            }
                // Reset the click
            else{
                removeButton(buttonPressed!)
                buttonPressed?.setTitle("", for: .normal)
            }
            tempPieceId = 0
        }
    }
    
    

    @IBAction func gamePause(_ sender : UITapGestureRecognizer){
        if !inProgess {
            startNewGame()
            return
        }
        if isRunning {
            pauseGame()
        }
        else {
            resumeGame()
        }
    }
    
    // Status bar is hidden i.e. full screen game
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    
    
    // MARK: - ==== ViewProperties ====
    
    var isAlreadyInPause = false // This variable is for pause and change configuration
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isAlreadyInPause == false{
            if (!isRunning && inProgess){
                resumeGame()
            }
        }
        else{
            isAlreadyInPause = false
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if (isRunning && inProgess) {
            pauseGame()
        }
        else{
            isAlreadyInPause = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.isMultipleTouchEnabled = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
