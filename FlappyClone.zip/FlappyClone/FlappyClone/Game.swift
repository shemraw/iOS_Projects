//
//
//

import UIKit

class Game: NSObject {
    // Scores Array
    var scores:Array = [0, 0, 0]
}

